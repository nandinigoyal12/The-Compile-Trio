package com.examai.ui.pets;

import com.examai.model.AdoptionRequest;
import com.examai.model.Pet;
import com.examai.service.PetService;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AdoptionFormView {
    private final Pet pet;
    private final PetService petService = new PetService();

    public AdoptionFormView(Pet pet) {
        this.pet = pet;
    }

    public void show() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Adopt " + pet.getName());

        GridPane grid = new GridPane();
        grid.setPadding(new Insets(24));
        grid.setHgap(16);
        grid.setVgap(14);
        grid.getStyleClass().add("form-card");

        TextField fullName = new TextField();
        TextField email = new TextField();
        TextField phone = new TextField();
        TextArea message = new TextArea();
        message.setPrefRowCount(4);
        
        // Set placeholders for better user guidance
        fullName.setPromptText("Enter your full name (required)");
        email.setPromptText("your.email@example.com (required)");
        phone.setPromptText("Your contact number (required)");
        message.setPromptText("Tell us why you'd like to adopt " + pet.getName() + " (optional)");

        com.examai.model.User u = com.examai.util.Session.getUser();
        if (u != null) {
            fullName.setText(u.getFullName());
            email.setText(u.getEmail());
            phone.setText(u.getPhone() != null ? u.getPhone() : "");
        }

        // Create labels with required indicators
        Label fullNameLabel = new Label("Full Name *");
        Label emailLabel = new Label("Email Address *");
        Label phoneLabel = new Label("Phone Number *");
        Label messageLabel = new Label("Message");
        
        // Style the labels
        fullNameLabel.getStyleClass().add("form-label");
        emailLabel.getStyleClass().add("form-label");
        phoneLabel.getStyleClass().add("form-label");
        messageLabel.getStyleClass().add("form-label");

        grid.add(fullNameLabel, 0, 0);
        grid.add(fullName, 1, 0);
        grid.add(emailLabel, 0, 1);
        grid.add(email, 1, 1);
        grid.add(phoneLabel, 0, 2);
        grid.add(phone, 1, 2);
        grid.add(messageLabel, 0, 3);
        grid.add(message, 1, 3);

        Button submit = new Button("Submit");
        submit.getStyleClass().add("primary-btn");
        submit.setOnAction(e -> {
            // Validate required fields
            StringBuilder missingFields = new StringBuilder();
            if (fullName.getText().isBlank()) missingFields.append("• Full Name\n");
            if (email.getText().isBlank()) missingFields.append("• Email Address\n");
            if (phone.getText().isBlank()) missingFields.append("• Phone Number\n");
            
            if (missingFields.length() > 0) {
                Alert a = new Alert(Alert.AlertType.WARNING);
                a.setHeaderText("Required fields are missing:");
                a.setTitle("Missing Information");
                a.setContentText("Please fill in the following required fields:\n\n" + missingFields.toString());
                a.showAndWait();
                return;
            }
            if (!email.getText().contains("@")) {
                Alert a = new Alert(Alert.AlertType.WARNING);
                a.setHeaderText(null);
                a.setTitle("Invalid Email");
                a.setContentText("Please enter a valid email address.");
                a.showAndWait();
                return;
            }

            AdoptionRequest req = new AdoptionRequest(pet.getId(), fullName.getText(), email.getText(), phone.getText(), message.getText());
            boolean ok = petService.saveAdoptionRequest(req);
            Alert alert = new Alert(ok ? Alert.AlertType.INFORMATION : Alert.AlertType.ERROR);
            alert.setTitle(ok ? "Request Submitted" : "Submission Failed");
            alert.setHeaderText(null);
            alert.setContentText(ok ? "Your adoption request has been submitted." : "Unable to submit request. Please try again.");
            alert.showAndWait();
            if (ok) stage.close();
        });

        // Add a note about required fields
        Label noteLabel = new Label("* Required fields");
        noteLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #666;");
        grid.add(noteLabel, 1, 4);
        
        grid.add(submit, 1, 5);
        Scene scene = new Scene(grid, 520, 380);
        scene.getStylesheets().add(getClass().getResource("/styles/styles.css").toExternalForm());
        stage.setScene(scene);
        stage.showAndWait();
    }
}
