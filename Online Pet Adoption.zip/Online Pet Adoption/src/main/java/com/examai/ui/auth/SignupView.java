package com.examai.ui.auth;

import com.examai.service.AuthenticationService;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SignupView {
    private final AuthenticationService auth = new AuthenticationService();

    public void show(Stage stage) {
        javafx.scene.layout.BorderPane root = new javafx.scene.layout.BorderPane();
        root.setPadding(new Insets(24));
        Label title = new Label("Create Your Account");
        title.setText(title.getText().toUpperCase());
        title.getStyleClass().add("app-title");
        javafx.scene.layout.Region divider = new javafx.scene.layout.Region();
        divider.getStyleClass().add("title-divider");
        divider.setMinHeight(3);
        divider.setPrefWidth(220);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);

        TextField fullName = new TextField();
        TextField email = new TextField();
        PasswordField password = new PasswordField();
        TextField phone = new TextField();
        fullName.setPromptText("Your full name");
        email.setPromptText("you@example.com");
        password.setPromptText("Choose a strong password");
        phone.setPromptText("Optional");
        fullName.getStyleClass().add("text-field");
        email.getStyleClass().add("text-field");
        password.getStyleClass().add("password-field");
        phone.getStyleClass().add("text-field");

        grid.add(new Label("Full Name"), 0, 0);
        grid.add(fullName, 1, 0);
        grid.add(new Label("Email"), 0, 1);
        grid.add(email, 1, 1);
        grid.add(new Label("Password"), 0, 2);
        grid.add(password, 1, 2);
        grid.add(new Label("Phone (optional)"), 0, 3);
        grid.add(phone, 1, 3);

        Button createBtn = new Button("Create Account");
        createBtn.getStyleClass().add("primary-btn");
        createBtn.setOnAction(e -> {
            if (fullName.getText().isBlank() || email.getText().isBlank() || password.getText().isBlank()) {
                Alert a = new Alert(Alert.AlertType.WARNING);
                a.setHeaderText(null);
                a.setTitle("Missing Information");
                a.setContentText("Please fill Full Name, Email, and Password.");
                a.showAndWait();
                return;
            }
            String err = auth.signUp(fullName.getText(), email.getText(), password.getText(), phone.getText());
            if (err != null) {
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setHeaderText(null);
                a.setTitle("Sign Up Failed");
                a.setContentText(err);
                a.showAndWait();
                return;
            }
            Alert a = new Alert(Alert.AlertType.INFORMATION);
            a.setHeaderText(null);
            a.setTitle("Account Created");
            a.setContentText("Account created successfully!");
            a.showAndWait();
            new LoginView().show(stage);
        });

        Button cancelBtn = new Button("Cancel");
        cancelBtn.getStyleClass().add("secondary-btn");
        cancelBtn.setOnAction(e -> new LoginView().show(stage));

        javafx.scene.layout.HBox actions = new javafx.scene.layout.HBox(10, cancelBtn, createBtn);

        VBox card = new VBox(16, grid, actions);
        card.getStyleClass().add("form-card");
        VBox container = new VBox(16, title, divider, card);
        container.setAlignment(javafx.geometry.Pos.CENTER);
        root.setCenter(container);
        Scene scene = new Scene(root, 600, 380);
        scene.getStylesheets().add(getClass().getResource("/styles/styles.css").toExternalForm());
        stage.setTitle("Sign Up");
        stage.setScene(scene);
        stage.show();
    }
}
