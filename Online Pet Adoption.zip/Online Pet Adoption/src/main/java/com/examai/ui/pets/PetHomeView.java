package com.examai.ui.pets;

import com.examai.model.Pet;
import com.examai.service.PetService;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class PetHomeView {
    private final PetService petService = new PetService();

    public Parent createContent(Stage primaryStage) {
        BorderPane root = new BorderPane();
        Label title = new Label("Online Pet Adoption");
        title.getStyleClass().add("app-title");
        javafx.scene.control.Button logout = new javafx.scene.control.Button("Logout");
        logout.getStyleClass().add("primary-btn");
        logout.setOnAction(e -> {
            com.examai.util.Session.clear();
            new com.examai.ui.auth.LoginView().show(primaryStage);
        });
        javafx.scene.layout.HBox headerBar = new javafx.scene.layout.HBox();
        javafx.scene.layout.Region spacer = new javafx.scene.layout.Region();
        javafx.scene.layout.HBox.setHgrow(spacer, javafx.scene.layout.Priority.ALWAYS);
        headerBar.getChildren().addAll(title, spacer, logout);
        headerBar.setPadding(new Insets(16));
        headerBar.setSpacing(12);
        VBox header = new VBox(headerBar);
        header.setStyle("-fx-background-color: linear-gradient(to right, #6a82fb, #fc5c7d);");
        root.setTop(header);

        javafx.scene.layout.FlowPane list = new javafx.scene.layout.FlowPane();
        list.setPadding(new Insets(16));
        list.setHgap(16);
        list.setVgap(16);
        list.setPrefWrapLength(760);

        List<Pet> pets = petService.getAllPets();
        for (Pet pet : pets) {
            VBox card = new VBox(10);
            card.setAlignment(Pos.TOP_LEFT);
            card.setPadding(new Insets(12));
            card.getStyleClass().add("pet-card");
            card.setPrefWidth(230);

            ImageView imageView = new ImageView();
            imageView.setFitWidth(230);
            imageView.setFitHeight(140);
            imageView.setPreserveRatio(true);
            if (pet.getImageUrl() != null && !pet.getImageUrl().isEmpty()) {
                try { imageView.setImage(new Image(pet.getImageUrl(), true)); } catch (Exception ignored) {}
            }

            VBox info = new VBox(6);
            Label name = new Label(pet.getName());
            name.getStyleClass().add("pet-name");
            Label breed = new Label("Breed: " + pet.getBreed());
            Label age = new Label("Age: " + pet.getAge());
            Button details = new Button("Details");
            details.getStyleClass().add("primary-btn");
            details.setOnAction(e -> new PetDetailsView(pet).show());
            info.getChildren().addAll(name, breed, age, details);

            card.getChildren().addAll(imageView, info);
            list.getChildren().add(card);
        }

        ScrollPane scroll = new ScrollPane(list);
        scroll.setFitToWidth(true);
        root.setCenter(scroll);

        return root;
    }

    public void show(Stage stage) {
        Scene scene = new Scene((Parent) createContent(stage), 800, 600);
        stage.setTitle("Online Pet Adoption");
        stage.setScene(scene);
        stage.show();
    }
}
