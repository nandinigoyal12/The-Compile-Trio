package com.examai.ui.auth;

import com.examai.model.User;
import com.examai.service.AuthenticationService;
import com.examai.ui.pets.PetHomeView;
import com.examai.util.Session;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class LoginView {
    private final AuthenticationService auth = new AuthenticationService();

    public void show(Stage stage) {
        javafx.scene.layout.BorderPane root = new javafx.scene.layout.BorderPane();
        root.setPadding(new Insets(24));
        Label title = new Label("Welcome to Pet Adoption");
        title.setText(title.getText().toUpperCase());
        title.getStyleClass().add("app-title");
        javafx.scene.layout.Region divider = new javafx.scene.layout.Region();
        divider.getStyleClass().add("title-divider");
        divider.setMinHeight(3);
        divider.setPrefWidth(220);

        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(12);

        TextField email = new TextField();
        PasswordField password = new PasswordField();
        email.setPromptText("you@example.com");
        password.setPromptText("your password");
        email.getStyleClass().add("text-field");
        password.getStyleClass().add("password-field");

        grid.add(new Label("Email"), 0, 0);
        grid.add(email, 1, 0);
        grid.add(new Label("Password"), 0, 1);
        grid.add(password, 1, 1);

        Button loginBtn = new Button("Login");
        loginBtn.getStyleClass().add("primary-btn");
        loginBtn.setOnAction(e -> {
            User u = auth.login(email.getText(), password.getText());
            if (u == null) {
                Alert a = new Alert(Alert.AlertType.ERROR);
                a.setHeaderText(null);
                a.setTitle("Login Failed");
                a.setContentText("Invalid email or password.");
                a.showAndWait();
                return;
            }
            Session.setUser(u);
            PetHomeView home = new PetHomeView();
            Scene scene = new Scene(home.createContent(stage), 800, 600);
            scene.getStylesheets().add(getClass().getResource("/styles/styles.css").toExternalForm());
            stage.setScene(scene);
        });

        Hyperlink signupLink = new Hyperlink("Sign Up (Create New Account)");
        signupLink.setOnAction(e -> new SignupView().show(stage));

        VBox card = new VBox(16, grid, loginBtn, signupLink);
        card.getStyleClass().add("form-card");
        VBox container = new VBox(16, title, divider, card);
        container.setAlignment(javafx.geometry.Pos.CENTER);
        root.setCenter(container);
        Scene scene = new Scene(root, 600, 360);
        scene.getStylesheets().add(getClass().getResource("/styles/styles.css").toExternalForm());
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
    }
}
