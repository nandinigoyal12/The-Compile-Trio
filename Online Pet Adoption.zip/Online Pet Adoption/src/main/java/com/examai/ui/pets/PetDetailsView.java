package com.examai.ui.pets;

import com.examai.model.Pet;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class PetDetailsView {
    private final Pet pet;

    public PetDetailsView(Pet pet) {
        this.pet = pet;
    }

    public void show() {
        Stage stage = new Stage();
        stage.initModality(Modality.APPLICATION_MODAL);
        stage.setTitle("Pet Details");

        VBox layout = new VBox(12);
        layout.setPadding(new Insets(16));
        layout.getStyleClass().add("form-card");

        ImageView imageView = new ImageView();
        imageView.setFitWidth(300);
        imageView.setFitHeight(200);
        imageView.setPreserveRatio(true);
        if (pet.getImageUrl() != null && !pet.getImageUrl().isEmpty()) {
            try { imageView.setImage(new Image(pet.getImageUrl(), true)); } catch (Exception ignored) {}
        }

        Label name = new Label(pet.getName());
        name.getStyleClass().add("pet-name");
        Label info = new Label(pet.getBreed() + " • Age " + pet.getAge());
        Label desc = new Label(pet.getDescription() == null ? "" : pet.getDescription());
        Button adopt = new Button("Adopt This Pet");
        adopt.getStyleClass().add("primary-btn");
        adopt.setOnAction(e -> new AdoptionFormView(pet).show());

        layout.getChildren().addAll(imageView, name, info, desc, adopt);
        Scene scene = new Scene(layout, 420, 420);
        scene.getStylesheets().add(getClass().getResource("/styles/styles.css").toExternalForm());
        stage.setScene(scene);
        stage.showAndWait();
    }
}
