package com.examai.model;

public class AdoptionRequest {
    private int id;
    private int petId;
    private String fullName;
    private String email;
    private String phone;
    private String message;

    public AdoptionRequest(int petId, String fullName, String email, String phone, String message) {
        this.petId = petId;
        this.fullName = fullName;
        this.email = email;
        this.phone = phone;
        this.message = message;
    }

    public int getPetId() {
        return petId;
    }

    public String getFullName() {
        return fullName;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public String getMessage() {
        return message;
    }
}
