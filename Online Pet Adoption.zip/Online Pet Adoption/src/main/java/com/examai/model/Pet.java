package com.examai.model;

public class Pet {
    private int id;
    private String name;
    private String breed;
    private int age;
    private String description;
    private String imageUrl;

    public Pet(int id, String name, String breed, int age, String description, String imageUrl) {
        this.id = id;
        this.name = name;
        this.breed = breed;
        this.age = age;
        this.description = description;
        this.imageUrl = imageUrl;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getBreed() {
        return breed;
    }

    public int getAge() {
        return age;
    }

    public String getDescription() {
        return description;
    }

    public String getImageUrl() {
        return imageUrl;
    }
}
