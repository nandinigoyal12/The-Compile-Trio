package com.examai.model;

public class User {
    private int id;
    private String fullName;
    private String email;
    private String passwordHash;
    private String phone;

    public User(int id, String fullName, String email, String passwordHash, String phone) {
        this.id = id;
        this.fullName = fullName;
        this.email = email;
        this.passwordHash = passwordHash;
        this.phone = phone;
    }

    public int getId() { return id; }
    public String getFullName() { return fullName; }
    public String getEmail() { return email; }
    public String getPasswordHash() { return passwordHash; }
    public String getPhone() { return phone; }
}
