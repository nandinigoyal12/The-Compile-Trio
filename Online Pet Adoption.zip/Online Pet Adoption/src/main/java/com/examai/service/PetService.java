package com.examai.service;

import com.examai.database.DatabaseConfig;
import com.examai.model.AdoptionRequest;
import com.examai.model.Pet;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PetService {
    public List<Pet> getAllPets() {
        List<Pet> pets = new ArrayList<>();
        String sql = "SELECT id, name, breed, age, description, image_url FROM pets ORDER BY id";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                pets.add(new Pet(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("breed"),
                    rs.getInt("age"),
                    rs.getString("description"),
                    rs.getString("image_url")
                ));
            }
        } catch (SQLException e) {
            pets.add(new Pet(1, "Bella", "Labrador Retriever", 3, "Friendly and energetic.", null));
            pets.add(new Pet(2, "Max", "German Shepherd", 4, "Loyal and intelligent.", null));
            pets.add(new Pet(3, "Luna", "Persian Cat", 2, "Calm and affectionate.", null));
        }
        return pets;
    }

    public Pet getPetById(int id) {
        String sql = "SELECT id, name, breed, age, description, image_url FROM pets WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Pet(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getString("breed"),
                        rs.getInt("age"),
                        rs.getString("description"),
                        rs.getString("image_url")
                    );
                }
            }
        } catch (SQLException e) {
        }
        for (Pet p : getAllPets()) {
            if (p.getId() == id) return p;
        }
        return null;
    }

    public boolean saveAdoptionRequest(AdoptionRequest request) {
        String sql = "INSERT INTO adoption_requests (pet_id, user_id, full_name, email, phone, message) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, request.getPetId());
            Integer userId = com.examai.util.Session.getUser() != null ? com.examai.util.Session.getUser().getId() : null;
            if (userId == null) ps.setNull(2, java.sql.Types.INTEGER); else ps.setInt(2, userId);
            ps.setString(3, request.getFullName());
            ps.setString(4, request.getEmail());
            ps.setString(5, request.getPhone());
            ps.setString(6, request.getMessage());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false;
        }
    }
}
