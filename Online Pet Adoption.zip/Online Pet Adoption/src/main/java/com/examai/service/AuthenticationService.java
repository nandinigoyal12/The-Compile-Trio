package com.examai.service;

import com.examai.database.DatabaseConfig;
import com.examai.model.User;
import org.mindrot.jbcrypt.BCrypt;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AuthenticationService {
    public User login(String email, String password) {
        String sql = "SELECT id, full_name, email, password_hash, phone FROM users WHERE email = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    String hash = rs.getString("password_hash");
                    if (hash != null && BCrypt.checkpw(password, hash)) {
                        return new User(
                            rs.getInt("id"),
                            rs.getString("full_name"),
                            rs.getString("email"),
                            hash,
                            rs.getString("phone")
                        );
                    }
                }
            }
        } catch (SQLException e) {
        }
        return null;
    }

    public String signUp(String fullName, String email, String password, String phone) {
        String checkSql = "SELECT id FROM users WHERE email = ?";
        String insertSql = "INSERT INTO users (full_name, email, password_hash, phone) VALUES (?, ?, ?, ?)";
        try (Connection conn = DatabaseConfig.getConnection()) {
            try (PreparedStatement check = conn.prepareStatement(checkSql)) {
                check.setString(1, email);
                try (ResultSet rs = check.executeQuery()) {
                    if (rs.next()) return "Email already in use";
                }
            }
            String hash = BCrypt.hashpw(password, BCrypt.gensalt(10));
            try (PreparedStatement ins = conn.prepareStatement(insertSql)) {
                ins.setString(1, fullName);
                ins.setString(2, email);
                ins.setString(3, hash);
                ins.setString(4, phone);
                ins.executeUpdate();
            }
            return null;
        } catch (SQLException e) {
            return "Failed to create account";
        }
    }
}
