package com.examai.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DatabaseConfig {
    private static final String DB_NAME = "pet";
    private static final String SERVER_URL = "jdbc:mysql://localhost:3306/";
    private static final String OPTIONS = "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String URL = SERVER_URL + DB_NAME + OPTIONS;
    private static final String USER = "root";
    private static final String PASSWORD = "Shivam@8453";

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            ensureDatabase();
            initializeDatabase();
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL  JDBC Driver not found: " + e.getMessage());
        }
    }

    private static void initializeDatabase() {
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement()) {
            String createUsersTable = """
                CREATE TABLE IF NOT EXISTS users (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    full_name VARCHAR(255) NOT NULL,
                    email VARCHAR(255) UNIQUE NOT NULL,
                    password_hash VARCHAR(255) NOT NULL,
                    phone VARCHAR(50),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """;
            stmt.executeUpdate(createUsersTable);
            

            String createPetsTable = """
                CREATE TABLE IF NOT EXISTS pets (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(255) NOT NULL,
                    breed VARCHAR(255) NOT NULL,
                    age INT NOT NULL,
                    description TEXT,
                    image_url VARCHAR(512),
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """;
            stmt.executeUpdate(createPetsTable);

            String createAdoptionRequestsTable = """
                CREATE TABLE IF NOT EXISTS adoption_requests (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    pet_id INT NOT NULL,
                    user_id INT,
                    full_name VARCHAR(255) NOT NULL,
                    email VARCHAR(255) NOT NULL,
                    phone VARCHAR(50),
                    message TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (pet_id) REFERENCES pets(id),
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )
            """;
            stmt.executeUpdate(createAdoptionRequestsTable);

            try {
                stmt.executeUpdate("ALTER TABLE adoption_requests ADD COLUMN IF NOT EXISTS user_id INT");
            } catch (SQLException ignored) {}
            try {
                stmt.executeUpdate("ALTER TABLE adoption_requests ADD FOREIGN KEY (user_id) REFERENCES users(id)");
            } catch (SQLException ignored) {}

            try (PreparedStatement countPets = conn.prepareStatement("SELECT COUNT(*) FROM pets")) {
                ResultSet rs = countPets.executeQuery();
                int count = rs.next() ? rs.getInt(1) : 0;
                if (count == 0) {
                    String insertSamplePets = """
                        INSERT INTO pets (name, breed, age, description, image_url) VALUES
                        ('Bella', 'Labrador Retriever', 3, 'Friendly and energetic. Loves walks and playing fetch.', NULL),
                        ('Max', 'German Shepherd', 4, 'Loyal and intelligent. Great family companion.', NULL),
                        ('Luna', 'Persian Cat', 2, 'Calm and affectionate. Enjoys quiet spaces.', NULL)
                    """;
                    stmt.executeUpdate(insertSamplePets);
                }
            } catch (SQLException ignored) {
            }

        } catch (SQLException e) {
            System.err.println("Error initializing database: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
    private static void ensureDatabase() {
        try (Connection conn = DriverManager.getConnection(SERVER_URL + OPTIONS, USER, PASSWORD);
             Statement stmt = conn.createStatement()) {
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS " + DB_NAME);
        } catch (SQLException ignored) {
        }
    }
}
